package genericos;

import java.util.ArrayList;

public class Generica<T> {
    //metodos que permiten visualizar,insertar, actualizar, o eliminar datos en una lista de tipo T

    //defino coleccion de datos de tipo T
    private ArrayList<T> coleccion = new ArrayList<>();

    public void insertar(T elemento){
        //codigo para insertar el elemento en la coleccion
        coleccion.add(elemento);//metodo delegado add
    }

    public void eliminar(T elemento){
        //codigo para eliminar el elemento de la coleccion
        coleccion.remove(elemento);//metodo delegado remove
    }

    public void actualizar(T elemento){
        //codigo para actualizar el elemento en la coleccion
        int index = coleccion.indexOf(elemento);
        if (index != -1) {
            coleccion.set(index, elemento);
        }
    }

    public void visualizar(){
        //codigo para visualizar los elementos de la coleccion
        for (T elemento : coleccion) {
            System.out.println(elemento);
        }
    }

    
}
