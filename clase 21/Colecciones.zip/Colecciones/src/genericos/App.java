package genericos;

public class App {
    public static void main(String[] args) {
        //creo una instancia de la clase generica para manejar datos de tipo String
        Generica<String> genericaString = new Generica<>();
        genericaString.insertar("Hola");
        genericaString.insertar("Mundo");
        genericaString.visualizar();
        genericaString.eliminar("Hola");
        genericaString.visualizar();
        genericaString.actualizar("Mundo");
        genericaString.visualizar();

        //creo una instancia de la clase generica para manejar datos de tipo Integer
        Generica<Integer> genericaInteger = new Generica<>();
        genericaInteger.insertar(1);
        genericaInteger.insertar(2);
        genericaInteger.visualizar();
        genericaInteger.eliminar(1);
        genericaInteger.visualizar();
        genericaInteger.actualizar(2);
        genericaInteger.visualizar();

        //creo una instancia de la clase generica para manejar datos de tipo Auto
        Generica<Auto> genericaAuto = new Generica<>();
        Auto auto1 = new Auto("Toyota", 20000);
        Auto auto2 = new Auto("Honda", 18000);
        genericaAuto.insertar(auto1);
        genericaAuto.insertar(auto2);
        genericaAuto.visualizar();
        genericaAuto.eliminar(auto1);
        genericaAuto.visualizar();
        genericaAuto.actualizar(auto2);
        genericaAuto.visualizar();
    }
}
