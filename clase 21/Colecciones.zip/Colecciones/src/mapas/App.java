package mapas;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.TreeMap;

public class App {
    public static void main(String[] args) throws Exception {
        //Creo un diccionario de tipo HashMap
        //no respeta el orden de inserción, no permite claves duplicadas, permite un valor nulo y una clave nula
        // HashMap<String, String> diccionario = new HashMap<>();        
        
        //respeta el orden de inserción
        // LinkedHashMap<String, String> diccionario = new LinkedHashMap<>();        
        
        //ordena las claves de forma natural (alfabéticamente para Strings)
        TreeMap<String, String> diccionario = new TreeMap<>();        

        //Agrego elementos al diccionario
        diccionario.put("Hola", "Hello");
        diccionario.put("Adiós", "Goodbye");
        diccionario.put("Gracias", "Thank you");
        diccionario.put("Por favor", "Please");

        //Imprimo el diccionario
        System.out.println(diccionario);

        //listar solo las claves
        System.out.println(diccionario.keySet());

        //listar solo los valores
        System.out.println(diccionario.values());

        //mostrar el valor de una clave específica
        System.out.println(diccionario.get("Hola"));

        //mostrar el valor de una clave que no existe (devuelve null)
        System.out.println(diccionario.get("Amigo"));

        //mostrar la clave de un valor específico (no es eficiente, se debe recorrer el diccionario)
        String valorBuscado = "Thank you";
        String claveEncontrada = null;
        for (String clave : diccionario.keySet()) {
            if (diccionario.get(clave).equals(valorBuscado)) {
                claveEncontrada = clave;
                break;
            }
        }
        System.out.println("La clave del valor '" + valorBuscado + "' es: " + claveEncontrada);
    }
}
