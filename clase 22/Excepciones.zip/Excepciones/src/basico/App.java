package basico;

public class App {
    public static void main(String[] args) {

        try {
            System.out.println("Principio");

            int n = 10 / 0;// se lanza una ArithmeticException
            System.out.println("n = " + n);

            System.out.println("Final");
        } catch (ArithmeticException e) {
            // System.out.println("Error: " + e.getMessage());
            System.out.println("Error: No se puede dividir por cero");
        } finally {
            System.out.println("Fin del programa");
        }
    }
}
