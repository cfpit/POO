package multiple;

public class App {
    public static void main(String[] args) {
        //try con multiples catch
        //AritmeticException, NumberFormatException, ArrayIndexOutOfBoundsException
        // NullPointerException y Exception
        try {
            int a = 10 / 0;
            int b = Integer.parseInt("abc");
            int[] c = new int[5];
            c[10] = 1;
            String d = null;
            d.length();
        } catch (ArithmeticException e) {
            System.out.println("Error: División por cero");
        } catch (NumberFormatException e) {
            System.out.println("Error: Formato de número no válido");
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Error: Índice de array fuera de límites");
        } catch (NullPointerException e) {
            System.out.println("Error: Referencia nula");
        } catch (Exception e) {
            System.out.println("Error: Excepción general");
        } finally {
            System.out.println("Bloque finally ejecutado");
        }
    }
}
