package enumeraciones;

public enum Dias {
    //coleccion de constantes, cada una de ellas es un objeto del tipo Dias
    LUNES, MARTES, MIERCOLES, JUEVES, VIERNES, SABADO, DOMINGO
}
