package enumeraciones;
public class App {
    public static void main(String[] args) throws Exception {
        //para usar una enumeracion, se hace referencia a ella por su nombre
        //y luego se accede a cada uno de sus objetos por su nombre
        Dias dia = Dias.LUNES;
        System.out.println("El dia es: " + dia);

        //tambien se puede usar un switch para evaluar el valor de una enumeracion
        switch (dia) {
            case LUNES:
                System.out.println("Es el primer dia de la semana");
                break;
            case MARTES:
                System.out.println("Es el segundo dia de la semana");
                break;
            case MIERCOLES:
                System.out.println("Es el tercer dia de la semana");
                break;
            case JUEVES:
                System.out.println("Es el cuarto dia de la semana");
                break;
            case VIERNES:
                System.out.println("Es el quinto dia de la semana");
                break;
            case SABADO:
                System.out.println("Es el sexto dia de la semana");
                break;
            case DOMINGO:
                System.out.println("Es el septimo dia de la semana");
                break;
        }
    }
}
