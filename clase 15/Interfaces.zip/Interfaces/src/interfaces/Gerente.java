package interfaces;

public class Gerente implements Empleado {

    //atributos
    private String nombre;
    private int base;
    private int antiguedad;

    //constructor vacio
    public Gerente() {
    }

    //constructor con parametros
    public Gerente(String nombre, int base, int antiguedad) {
        this.nombre = nombre;
        this.base = base;
        this.antiguedad = antiguedad;
    }

    //metodos get y set
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getBase() {
        return base;
    }

    public void setBase(int base) {
        this.base = base;
    }

    public int getAntiguedad() {
        return antiguedad;
    }

    public void setAntiguedad(int antiguedad) {
        this.antiguedad = antiguedad;
    }

    //metodo toString
    @Override
    public String toString() {
        return "Gerente{" +
                "nombre='" + nombre + '\'' +
                ", base=" + base +
                ", antiguedad=" + antiguedad +
                '}';
    }

    //metodo calcularSueldo
    @Override
    public void calcularSueldo() {
        int sueldo = base + (antiguedad * 100); 
        System.out.println("El sueldo del gerente " + nombre + " es: " + sueldo);
    }

}
