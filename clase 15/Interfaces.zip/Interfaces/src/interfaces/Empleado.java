package interfaces;

public interface Empleado {
    //contiene un contrato que deben cumplir las clases que implementen esta interfaz

    //el contrato es el conjunto de metodos abstractos que deben implementar las clases que implementen esta interfaz

    // public void metodo1();
    // public void metodo2();
    // public void metodo3();

    public void calcularSueldo();


}
