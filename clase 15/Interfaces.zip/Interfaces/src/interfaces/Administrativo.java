package interfaces;

public class Administrativo implements Empleado {

    //atributos
    private String nombre;
    private int cantidad;
    private int precio;

    //constructor vacio
    public Administrativo() {
    }

    //constructor con parametros
    public Administrativo(String nombre, int cantidad, int precio) {
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.precio = precio;
    }

    //metodos get y set
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    //metodo toString
    @Override
    public String toString() {
        return "Administrativo{" +
                "nombre='" + nombre + '\'' +
                ", cantidad=" + cantidad +
                ", precio=" + precio +
                '}';
    }

    //metodo calcularSueldo
    @Override
    public void calcularSueldo() {
        int sueldo = cantidad * precio;
        System.out.println("El sueldo del administrativo " + nombre + " es: " + sueldo);
    }

    
    




}
