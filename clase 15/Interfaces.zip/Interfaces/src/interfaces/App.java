package interfaces;
public class App {
    public static void main(String[] args) throws Exception {
        //creamos un objeto de la clase Gerente
        Gerente gerente1 = new Gerente("Juan", 5000, 5);
        //creamos un objeto de la clase Administrativo
        Administrativo administrativo1 = new Administrativo("Maria", 10, 200);

        //imprimimos los objetos
        System.out.println(gerente1);
        System.out.println(administrativo1);

        //calculamos el sueldo de los empleados
        gerente1.calcularSueldo();
        administrativo1.calcularSueldo();
    }
}
