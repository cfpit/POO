package abstractas;

public class Avion extends Vehiculo {

    //atributos
    private String nombre;

    //constructor vacio
    public Avion() {
    }

    //constructor con parametros
    public Avion(int velocidad, String nombre) {
        super(velocidad);
        this.nombre = nombre;
    }

    //getters y setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    //metodo toString
    @Override
    public String toString() {
        return "Avion [nombre=" + nombre + ", velocidad=" + super.toString() + "]";
    }


    //implementacion del metodo abstracto acelerar
    @Override
    public void acelerar() {
        this.velocidad += 50;
    }

}
