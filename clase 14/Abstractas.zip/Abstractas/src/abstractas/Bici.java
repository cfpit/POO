package abstractas;

public class Bici extends Vehiculo {

    //atributos
    private int rodado;

    //constructor vacio
    public Bici() {
    }

    //constructor con parametros
    public Bici(int velocidad, int rodado) {
        super(velocidad);
        this.rodado = rodado;
    }

    //getters y setters
    public int getRodado() {
        return rodado;
    }

    public void setRodado(int rodado) {
        this.rodado = rodado;
    }

    //metodo toString
    @Override
    public String toString() {
        return "Bici [rodado=" + rodado + ", velocidad=" + super.toString() + "]";
    }

    

    //implementacion del metodo abstracto acelerar
    @Override
    public void acelerar() {
        this.velocidad += 5;
    }
    

}
