package abstractas;

public abstract class Vehiculo {
    //atributos
    protected int velocidad;

    //constructor vacio
    public Vehiculo() {
    }

    //constructor con parametros
    public Vehiculo(int velocidad) {
        this.velocidad = velocidad;
    }   

    //getters y setters
    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }

    //metodo abstracto: no tiene cuerpo, solo la firma, 
    //y debe ser implementado por las clases hijas
    public abstract void acelerar();

    //metodo toString
    @Override
    public String toString() {
        return "Vehiculo [velocidad=" + velocidad + "]";
    }

}
