package abstractas;
public class App {
    public static void main(String[] args) throws Exception {
        //no puedo crear un objeto de una clase abstracta (Vehiculo) 
        // Vehiculo v = new Vehiculo();

        Bici bici = new Bici(10, 26);
        System.out.println("Antes: " + bici);
        bici.acelerar();//10 --> 15 km/h
        System.out.println("Después: " + bici);

        Avion avion = new Avion(500, "Boeing 747");
        System.out.println("Antes: " + avion);
        avion.acelerar();//500 --> 550 km/h
        System.out.println("Después: " + avion);

    }
}
