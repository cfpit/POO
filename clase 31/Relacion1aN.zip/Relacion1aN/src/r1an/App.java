package r1an;

public class App {
    public static void main(String[] args) {
        Concesionaria concesionaria = new Concesionaria("AutoMax");

        Auto a1 = new Auto("Toyota");
        Auto a2 = new Auto("Ford");
        Auto a3 = new Auto("Honda");

        concesionaria.agregarAuto(a1);
        concesionaria.agregarAuto(a2);
        concesionaria.agregarAuto(a3);

        System.out.println(concesionaria);
    }
}
