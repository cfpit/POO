package r1an;

public class Auto {

    private String marca;

    public Auto(String marca) {
        this.marca = marca;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    @Override
    public String toString() {
        return "Auto [marca=" + marca + "]";
    }
}
