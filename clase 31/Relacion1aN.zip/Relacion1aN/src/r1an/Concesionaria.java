package r1an;

import java.util.ArrayList;
import java.util.List;

public class Concesionaria {

    private String nombre;
    private List<Auto> autos;  // relacion 1 a N

    public Concesionaria(String nombre) {
        this.nombre = nombre;
        this.autos = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Auto> getAutos() {
        return autos;
    }

    public void agregarAuto(Auto auto) {
        this.autos.add(auto);
    }

    public void eliminarAuto(Auto auto) {
        this.autos.remove(auto);
    }

    @Override
    public String toString() {
        return "Concesionaria [nombre=" + nombre + ", autos=" + autos + "]";
    }
}
