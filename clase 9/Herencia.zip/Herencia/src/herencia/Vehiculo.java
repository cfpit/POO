package herencia;

public class Vehiculo {
    //atributos
    private String color;
    private int velocidad;

    //constructor vacio
    public Vehiculo() {
    }

    //constructor con parametros
    public Vehiculo(String color, int velocidad) {
        this.color = color;
        this.velocidad = velocidad;
    }

    //getters y setters
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }

    //metodo acelerar
    public void acelerar(int incremento) {
        this.velocidad += incremento;
    }

    //metodo toString
    @Override
    public String toString() {
        return "Vehiculo{ color= " + color + ", velocidad= " + velocidad + " }";
    }
}
