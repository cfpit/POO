package herencia;

public class Moto extends Vehiculo {
    //atributos
    private int cilindrada;

    //constructor vacio
    public Moto() {
    }

    //constructor con parametros
    public Moto(String color, int velocidad, int cilindrada) {
        super(color, velocidad);
        this.cilindrada = cilindrada;

    }

    //getters y setters
    public int getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(int cilindrada) {
        this.cilindrada = cilindrada;
    }

    //metodo toString
    @Override
    public String toString() {
        return "Moto{ " + super.toString() + ", cilindrada= " + cilindrada + " }";
    }

}
