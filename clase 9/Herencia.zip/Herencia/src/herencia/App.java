package herencia;

public class App {
    public static void main(String[] args) throws Exception {
        //creo un vehiculo, un avion y una moto
        Vehiculo v = new Vehiculo("Rojo", 0);
        Avion a = new Avion("Blanco", 0, "ABC-123");
        Moto m = new Moto("Negra", 0, 150);

        //comportamiento de cada objeto
        v.acelerar(50);
        a.acelerar(200);
        m.acelerar(100);

        //imprimo los objetos
        System.out.println(v);
        System.out.println(a);
        System.out.println(m);

    }
}
