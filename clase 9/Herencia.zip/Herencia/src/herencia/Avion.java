package herencia;

public class Avion extends Vehiculo {
    //atributos
    private String vuelo;

    //constructor vacio
    public Avion() {
    }

    //constructor con parametros
    public Avion(String color, int velocidad, String vuelo) {
        super(color, velocidad);
        this.vuelo = vuelo;
    }

    //getters y setters
    public String getVuelo() {
        return vuelo;
    }

    public void setVuelo(String vuelo) {
        this.vuelo = vuelo;
    }

    //metodo toString
    @Override
    public String toString() {
        return "Avion{ " + super.toString() + ", vuelo= " + vuelo + " }";
    }

}
