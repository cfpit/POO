package comparacion;

public class App {
    public static void main(String[] args) throws Exception {
        Cliente cliente1 = new Cliente("Juan", 30);
        Cliente cliente2 = new Cliente("Juan", 30);

        System.out.println("Comparacion de Contenidos: ");
        
        if (cliente1.equals(cliente2)) {
            System.out.println("igual contenido.");
        } else {
            System.out.println("contenido diferente.");
        }
        
        System.out.println("------------------------------");

        System.out.println("Comparacion de Referencias: ");
        if (cliente1 == cliente2) {
            System.out.println("misma referencia.");
        } else {
            System.out.println("referencias diferentes.");
        }
    }
}
