package lector;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class App {
    public static void main(String[] args) throws FileNotFoundException, IOException {

        // manejar con try catch para manejar excepciones
        try {
            // creo un objeto de tipo File q guarda la ruta del archivo a leer
            File archivo = new File("src/lector/origen.txt");

            // creo el stream de lectura
            BufferedReader lector = new BufferedReader(new FileReader(archivo));

            // algoritmo de lectura del archivo
            String lineaLeida = "";
            boolean eof = false;

            while (!eof) {
                lineaLeida = lector.readLine();
                if (lineaLeida != null) {
                    System.out.println(lineaLeida);
                } else {
                    eof = true;
                }
            }
            // cierro el stream de lectura
            lector.close();
        } catch (FileNotFoundException e) {
            System.out.println("No se encuentra el archivo a leer");
        } catch (IOException e) {
            System.out.println("Error al leer el archivo");
        } catch (Exception e) {
            System.out.println("Error desconocido");
        }
    }

}
