package operadores;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        //ingreso por teclado 2 numeros enteros mediante la clase Scanner y muestro el resultado de las operaciones suma, resta, multiplicacion, division y modulo
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese el primer numero: "); 
        int num1 = sc.nextInt();
        System.out.print("Ingrese el segundo numero: ");
        int num2 = sc.nextInt();
        System.out.println("Suma: " + (num1 + num2));
        System.out.println("Resta: " + (num1 - num2));
        System.out.println("Multiplicacion: " + (num1 * num2));
        System.out.println("Division: " + (num1 / num2));
        System.out.println("Modulo: " + (num1 % num2));
    }
}
