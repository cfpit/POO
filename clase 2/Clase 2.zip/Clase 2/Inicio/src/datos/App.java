package datos;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");

        // variables de tipo enteros
        byte edad = 20;// 1 byte = 8 bits = 256 valores (0 a 255)
        short numero = 1000;// 2 bytes = 16 bits = 65536 valores (-32768 a 32767)
        int numero2 = 100000;// 4 bytes = 32 bits = 4294967296 valores (-2147483648 a 2147483647)
        long numero3 = 1000000000L;// 8 bytes = 64 bits = 18446744073709551616 valores (-9223372036854775808 a 9223372036854775807)

        // variables de tipo flotantes
        float numero4 = 3.14f;// 4 bytes = 32 bits = 6-7 dígitos decimales de precisión
        double numero5 = 3.141592653589793;// 8 bytes = 64 bits = 15 dígitos decimales de precisión

        // variables de tipo booleano
        boolean esVerdadero = true;
        boolean esFalso = false;

        //constante iva
        final double IVA = 0.21;
        //calcular el precio con iva de un producto
        double precio = 100.0;
        double precioConIva = precio + (precio * IVA);  
        System.out.println("El precio con IVA es: " + precioConIva);

        //cadena de caracteres
        String nombre = "Juan Perez";
        System.out.println("Hola, " + nombre);

        //caracter
        char letra = 'A';
        System.out.println("La letra es: " + letra);
    }
}
