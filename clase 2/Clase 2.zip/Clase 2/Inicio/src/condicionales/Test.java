package condicionales;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        //creo un objeto Scanner
        Scanner lector = new Scanner(System.in);

        /*
            Scanner(System.in) es el metodo constructor de la clase Scanner.
            new Scanner(System.in) es el objeto Scanner
            lector es la variable que hace referencia al objeto Scanner(o sea, guarda el objeto)


        */

        System.out.println("Introduce un dia: ");    
        String dia = lector.next();
        System.out.println("Tenes dinero?: ");    
        String dinero = lector.next();
        
        if (dia.equals("sabado") && dinero.equals("si")) {
            System.out.println("Vamos al cine");
        } else {
            System.out.println("Nos quedamos en casa");
        }

    }
}
