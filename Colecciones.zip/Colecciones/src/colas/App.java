package colas;

import java.util.LinkedList;
import java.util.Queue;

public class App {
    public static void main(String[] args) throws Exception {
        //creo un objeto de tipo Queue
        Queue<String> cola = new LinkedList<>();

        //agrego elementos a la cola
        cola.add("Elemento 1");
        cola.add("Elemento 2");
        cola.add("Elemento 3");

        //muestro los elementos de la cola
        System.out.println("Elementos de la cola: " + cola);

        //peek() muestra el primer elemento de la cola sin eliminarlo
        System.out.println("Primer elemento (peek): " + cola.peek());

        //poll() muestra y elimina el primer elemento de la cola
        System.out.println("Primer elemento (poll): " + cola.poll());

        //muestro los elementos de la cola después de poll()
        System.out.println("Elementos de la cola después de poll(): " + cola);
    }
}
