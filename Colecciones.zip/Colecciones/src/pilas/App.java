package pilas;

import java.util.Stack;

public class App {
    public static void main(String[] args) {
        //creo una coleccion de tipo Stack
        Stack<String> pila = new Stack<>();

        //agrego elementos a la pila
        pila.push("Elemento 1");
        pila.push("Elemento 2");
        pila.push("Elemento 3");

        //muestro los elementos de la pila
        System.out.println("Elementos de la pila: " + pila);

        //peek() muestra el último elemento de la pila sin eliminarlo
        System.out.println("Último elemento (peek): " + pila.peek());

        //pop() muestra y elimina el último elemento de la pila
        System.out.println("Último elemento (pop): " + pila.pop());

        //muestro los elementos de la pila después de pop()
        System.out.println("Elementos de la pila después de pop(): " + pila);
    }
}
