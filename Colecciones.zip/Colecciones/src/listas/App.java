package listas;

import java.util.ArrayList;
import java.util.Iterator;

public class App {
    public static void main(String[] args) {
        //creo una coleccion de tipo ArrayList
        ArrayList<Persona> lista = new ArrayList<>();

        //creo objetos de tipo Persona
        Persona p1 = new Persona("Juan", 25);
        Persona p2 = new Persona("Maria", 30);
        Persona p3 = new Persona("Pedro", 20);

        //agrego los objetos a la lista
        lista.add(p1);
        lista.add(p2);
        lista.add(p3);

        //agrego un objeto a la lista en una posicion especifica
        Persona p4 = new Persona("Ana", 22);
        lista.add(1, p4);

        //elimino un objeto de la lista
        lista.remove(p2);

        //elimino todos los objetos de la lista
        // lista.removeAll(lista);

        //imprimo la lista
        System.out.println("Lista de personas:" + lista);

        System.out.println("-----------------------------");

        System.out.println("Imprimo la lista con un for:");
        for (int i = 0; i < lista.size(); i++) {
            System.out.println(lista.get(i));
        }

        System.out.println("-----------------------------");

        System.out.println("Imprimo la lista de mayores de 20 con un for each:");
        for (Persona p : lista) {
            if (p.getEdad() > 20) {
                System.out.println(p);
            }
        }

        System.out.println("-----------------------------");

        System.out.println("recorro la lista con un patron de diseño Iterator:");
        Iterator<Persona> it = lista.iterator(); 
        
        while (it.hasNext()) {
            Persona p = it.next();
            System.out.println(p);
        }
    }
}
