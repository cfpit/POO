package r1a1;

public class Auto {
    //atributos
    private String marca;
    private Motor motor;//relacion 1 a 1 con Motor

    //constructor
    public Auto(String marca, Motor motor) {
        this.marca = marca;
        this.motor = motor;
    }

    //getters
    public String getMarca() {
        return marca;
    }

    public Motor getMotor() {
        return motor;
    }

    //setters
    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setMotor(Motor motor) {
        this.motor = motor;
    }

    //toString
    @Override
    public String toString() {
        return "Auto{" + "marca=" + marca + ", motor=" + motor + '}';
    }
}
