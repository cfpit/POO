package r1a1;

public class Motor {
    //atributo cilindrada
    private int cilindrada;

    //constructor
    public Motor(int cilindrada) {
        this.cilindrada = cilindrada;
    }

    //getter
    public int getCilindrada() {
        return cilindrada;
    }

    //setter
    public void setCilindrada(int cilindrada) {
        this.cilindrada = cilindrada;
    }

    //toString
    @Override
    public String toString() {
        return "cilindrada=" + cilindrada;
    }
}
