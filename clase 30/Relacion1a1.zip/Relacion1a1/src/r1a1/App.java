package r1a1;

public class App {
    public static void main(String[] args) throws Exception {
        //creamos un motor
        Motor motor1 = new Motor(2000);
        
        //creamos un auto
        Auto auto1 = new Auto("Toyota", motor1);
        
        //mostramos la información del auto
        System.out.println(auto1);
    }
}
