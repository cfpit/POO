package arrays;

public class Test {
    public static void main(String[] args) {
        //array de edades
        //declaro e instancio en la RAM el array
        int[] edades = new int[5];

        //inicializo el array con valores
        edades[0] = 10;
        edades[1] = 20;
        edades[2] = 30;
        edades[3] = 40;
        edades[4] = 50;

        //muestro el valor del array en la posicion 2
        System.out.println("La edad en la posición 2 es: " + edades[2]);

        //recorro el array con un bucle for
        System.out.println("Recorriendo el array de edades:");
        for (int i = 0; i < edades.length; i++) {
            System.out.println("Edad en la posición " + i + ": " + edades[i]);
        }

        //defino por extension un array de 5 nombres
        String[] nombres = {"Juan", "María", "Pedro", "Ana", "Luis"};

        //recorro el array de nombres con un bucle for-each
        System.out.println("Recorriendo el array de nombres:");
        for (String nombre : nombres) {
            System.out.println("Nombre: " + nombre);
        }


    }
}
