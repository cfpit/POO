package bucleWhile;

public class Test {
    public static void main(String[] args) {
        
        System.out.println("Inicio");
        int contador = 1;
        
        while (contador <= 5) {
            System.out.println(contador);
            contador++;
        }

        System.out.println("Fin");


    }
}
