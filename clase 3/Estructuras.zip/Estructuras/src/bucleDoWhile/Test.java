package bucleDoWhile;

public class Test {
    public static void main(String[] args) {
        int contador = 5;
        do {
            System.out.println("Valor de contador: " + contador);
            contador--;
        } while (contador > 0);
    }
}
