package condicionales;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) throws Exception {
        //Calculadora con switch. Ingreso de ambos numeros a operar por teclado
        Scanner lector = new Scanner(System.in);
        
        System.out.println("Ingrese el primer numero: ");
        double num1 = lector.nextDouble();
        
        System.out.println("Ingrese el segundo numero: ");
        double num2 = lector.nextDouble();
        
        System.out.println("Ingrese la operacion a realizar: +, -, *, /");
        String operacion = lector.next();
        
        switch (operacion) {
            case "+":
                System.out.println("Resultado: " + (num1 + num2));
                break;
            case "-":
                System.out.println("Resultado: " + (num1 - num2));
                break;
            case "*":
                System.out.println("Resultado: " + (num1 * num2));
                break;
            case "/":
                if (num2 != 0) {
                    System.out.println("Resultado: " + (num1 / num2));
                } else {
                    System.out.println("Error: Division por cero");
                }
                break;
            default:
                System.out.println("Operacion no valida");
        }

    }
}
