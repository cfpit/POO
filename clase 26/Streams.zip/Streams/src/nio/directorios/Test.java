package nio.directorios;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;

public class Test {

    public static void main(String[] args) {
        try {
                Path directorioCurso = Paths.get("src/nio/directorios/curso");

                if (!Files.exists(directorioCurso)) {
                    Files.createDirectory(directorioCurso);
                    System.out.println("¡Se creó satisfactoriamente el directorio!");
                } else {
                    System.out.println("El directorio ya existe.");
                }

                Path rutaArchivo = directorioCurso.resolve("miArchivo.txt");

                if (!Files.exists(rutaArchivo)) {
                    Files.createFile(rutaArchivo);
                    System.out.println("¡Se creó satisfactoriamente el archivo!");
                } else {
                    System.out.println("El archivo ya existe.");
                }

                // Escribir líneas al final del archivo
                Files.write(rutaArchivo,
                        Arrays.asList("Primera línea del archivo.", "Segunda línea del archivo."),
                        StandardCharsets.UTF_8,
                        StandardOpenOption.APPEND);

                System.out.println("¡Se escribió en el archivo satisfactoriamente!");
            } 
        catch (IOException ex) 
            {
                    ex.printStackTrace();
            }

    }
}
