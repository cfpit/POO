package copiadorBinario;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class App {
    public static void main(String[] args) throws Exception {
       //creo 2 objetos File para guardar las rutas de los archivos origen y destino
       File archivoOrigen = new File("src/copiadorBinario/origen.jpg");
       File archivoDestino = new File("src/copiadorBinario/destino.jpg");

         //creo 2 streams para la copia de la imagen
         FileInputStream lector = new FileInputStream(archivoOrigen);
         FileOutputStream escritor = new FileOutputStream(archivoDestino);

         //algoritmo de copia
         int byteLeido;
         while ((byteLeido = lector.read()) != -1) {
             escritor.write(byteLeido);
         }

         //cierro los streams
         lector.close();
         escritor.close();
    }
}
