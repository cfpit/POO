package claseString;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Método length");
        String nombre = "Juan";
        int cantidadCaracteres = nombre.length();   
        System.out.println("Cantidad de caracteres: " + cantidadCaracteres);

        System.out.println("---------------------------------------");

        System.out.println("Método charAt");
        char letra = nombre.charAt(2);//a
        System.out.println("Letra en la posición 2: " + letra);

        System.out.println("---------------------------------------");

        System.out.println("Método substring");
        String subcadena = nombre.substring(1, 3);//ua
        System.out.println("Subcadena desde la posición 1 hasta la 3: " + subcadena);

        System.out.println("---------------------------------------");

        System.out.println("Método indexOf");
        int posicion = nombre.indexOf('a');//2
        System.out.println("Posición de la primera aparición de 'a': " + posicion);

        System.out.println("---------------------------------------");

        System.out.println("Método equals");
        String nombre2 = "Juan";
        boolean sonIguales = nombre.equals(nombre2);//true
        System.out.println("¿Los nombres son iguales? " + sonIguales);

        System.out.println("---------------------------------------");

        System.out.println("Método equalsIgnoreCase");
        String nombre3 = "juan";
        boolean sonIgualesIgnoreCase = nombre.equalsIgnoreCase(nombre3);//true
        System.out.println("¿Los nombres son iguales ignorando mayúsculas y minúsculas? " + sonIgualesIgnoreCase);

        System.out.println("---------------------------------------");

        System.out.println("Método replace");
        String nombre4 = nombre.replace('a', 'o');//Juon
        System.out.println("Nombre con 'a' reemplazada por 'o': " + nombre4);

        System.out.println("---------------------------------------");

        System.out.println("Método toLowerCase");
        String nombreMinusculas = nombre.toLowerCase();//juan
        System.out.println("Nombre en minúsculas: " + nombreMinusculas);

        System.out.println("---------------------------------------");

        System.out.println("Método toUpperCase");
        String nombreMayusculas = nombre.toUpperCase();//JUAN
        System.out.println("Nombre en mayúsculas: " + nombreMayusculas);

        System.out.println("---------------------------------------");

        System.out.println("Método trim");
        String nombreConEspacios = "  Juan  ";
        String nombreSinEspacios = nombreConEspacios.trim();
        System.out.println("Nombre sin espacios al inicio y al final: '" + nombreSinEspacios + "'");

        System.out.println("---------------------------------------");

        System.out.println("Método split");
        // String frase = "Hola mundo desde Java";
        String frase = "Hola/mundo/desde/Java";
        // String[] palabras = frase.split(" ");
        String[] palabras = frase.split("/");
        System.out.println("Palabras en la frase:");
        for (String palabra : palabras) {
            System.out.println(palabra);
        }

        

    }
}
