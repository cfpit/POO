package propiedades;

public class App {
    public static void main(String[] args) {
        System.out.println(System.getProperties());

        System.out.println("------------------------------");

        System.out.println(System.getProperty("java.version"));
        System.out.println(System.getProperty("os.name"));
        System.out.println(System.getProperty("os.version"));

        //llamada al garbage collector
        System.gc();

    }
}
