package usuario;

public class NoHayMasPasajesException extends Exception {
    private String vuelo;
    private int asientosPedidos;

        public NoHayMasPasajesException(String vuelo, int asientosPedidos) {
            this.vuelo = vuelo;
            this.asientosPedidos = asientosPedidos;
        }

    //getters y setters
    public String getVuelo() {
        return vuelo;
    }

    public void setVuelo(String vuelo) {
        this.vuelo = vuelo;
    }

    public int getAsientosPedidos() {
        return asientosPedidos;
    }

    public void setAsientosPedidos(int asientosPedidos) {
        this.asientosPedidos = asientosPedidos;
    }

    //toString
    @Override
    public String toString() {
        return "NoHayMasPasajesException{" +
                "vuelo='" + vuelo + '\'' +
                ", asientosPedidos=" + asientosPedidos +
                '}';
    }

    //mensaje de error
    public String mostrarMensaje() {
        return "No hay más pasajes disponibles para el vuelo " + vuelo + " y se han pedido " + asientosPedidos + " asientos.";
    }
}
