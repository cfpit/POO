package usuario;

public class Vuelo {
    private String nombre;
    private int asientosDisponibles;

    public Vuelo(String nombre, int asientosDisponibles) {
        this.nombre = nombre;
        this.asientosDisponibles = asientosDisponibles;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getAsientosDisponibles() {
        return asientosDisponibles;
    }

    public void setAsientosDisponibles(int asientosDisponibles) {
        this.asientosDisponibles = asientosDisponibles;
    }

    //toString
    @Override
    public String toString() {
        return "Vuelo{" +
                "nombre='" + nombre + '\'' +
                ", asientosDisponibles=" + asientosDisponibles +
                '}';
    }

    //metodo vender pasajes
    public void venderPasajes(int cantidad) throws NoHayMasPasajesException {
        if (cantidad > asientosDisponibles) {
            throw new NoHayMasPasajesException(nombre, cantidad);
        } else {
            asientosDisponibles -= cantidad;
            System.out.println("Se han vendido " + cantidad + " pasajes para el vuelo " + nombre);
        }
    }
    

}
