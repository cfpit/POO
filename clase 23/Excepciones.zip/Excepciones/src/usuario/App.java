package usuario;

public class App {
    public static void main(String[] args) throws Exception {
        //creo un vuelo
        Vuelo vuelo1 = new Vuelo("Vuelo 1", 100);
        
        try {
            vuelo1.venderPasajes(50);
            vuelo1.venderPasajes(30);
            vuelo1.venderPasajes(30);//esta linea lanza excepcion
            vuelo1.venderPasajes(20);
        } catch (NoHayMasPasajesException e) {
            System.out.println(e.mostrarMensaje());
        }
    }
}
