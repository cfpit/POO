package polimorfismo;

public class AutoDeCarrera extends Auto {
    //atributos
    private String tipoAleron;

    //constructor vacio
    public AutoDeCarrera() {
    }

    //constructor con parametros
    public AutoDeCarrera(String marca, int velocidad, String tipoAleron) {
        super(marca, velocidad);
        this.tipoAleron = tipoAleron;
    }

    //getters y setters
    public String getTipoAleron() {
        return tipoAleron;
    }

    public void setTipoAleron(String tipoAleron) {
        this.tipoAleron = tipoAleron;
    }

    //redefino el metodo acelerar heredado dsd el padre Auto
    //porque el auto de carrera acelera mas rapido que el auto normal
    @Override
    public void acelerar() {
        velocidad += 50;
    }

    //metodo toString
    @Override
    public String toString() {
        return "AutoDeCarrera{" + super.toString() + ", tipoAleron=" + tipoAleron + '}';
    }

}
