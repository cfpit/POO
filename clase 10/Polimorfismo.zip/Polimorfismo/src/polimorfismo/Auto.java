package polimorfismo;

public class Auto {
    //atributos
    private String marca;
    protected int velocidad;

    //constructor vacio
    public Auto() {
    }

    //constructor con parametros
    public Auto(String marca, int velocidad) {
        this.marca = marca;
        this.velocidad = velocidad;
    }

    //getters y setters
    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }

    //metodo acelerar
    public void acelerar() {
        velocidad += 10;
    }

    //metodo toString
    @Override
    public String toString() {
        return "Auto{" + "marca=" + marca + ", velocidad=" + velocidad + '}';
    }
}
