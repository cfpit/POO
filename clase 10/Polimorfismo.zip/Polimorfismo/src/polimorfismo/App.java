package polimorfismo;
public class App {
    public static void main(String[] args) throws Exception {
        //creo un objeto de la clase Auto
        Auto auto1 = new Auto("Toyota", 100);
        System.out.println(auto1.toString());
        auto1.acelerar();//acelera de a 10 km/h
        System.out.println("Velocidad despues de acelerar: " + auto1.getVelocidad());

        System.out.println("-----------------------------");

        //creo un objeto de la clase AutoDeCarrera
        AutoDeCarrera auto2 = new AutoDeCarrera("Ferrari", 200, "titanio");
        System.out.println(auto2);
        auto2.acelerar();//acelera de a 50 km/h
        System.out.println("Velocidad despues de acelerar: " + auto2.getVelocidad());
    }
}
