package set;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class App {
    public static void main(String[] args) throws Exception {
        //Las colecciones de tipo set no permiten elementos duplicados, por lo que si se intenta agregar un elemento que ya existe, no se añadirá a la colección.
        //el HashSet no respeta el orden de inserción.
        // HashSet<String> nombres = new HashSet<>();

        //el LinkedHashSet mantiene el orden de inserción de los elementos.
        // LinkedHashSet<String> nombres = new LinkedHashSet<>();

        // El TreeSet ordena los elementos de forma natural (alfabéticamente para Strings)
        TreeSet<String> nombres = new TreeSet<>(); 
        TreeSet<Integer> numeros = new TreeSet<>(); 

        // Agregar elementos en las colecciónes
        nombres.add("Juan");
        nombres.add("María");
        nombres.add("Pedro");

        numeros.add(10);
        numeros.add(5);
        numeros.add(20);

        // Intentar agregar un elemento duplicado
        boolean agregado = nombres.add("Juan"); // Esto no se agregará porque "Juan" ya existe en la colección
        System.out.println("¿Se agregó 'Juan' nuevamente? " + agregado); // Imprime false

        System.out.println("-------------------------------");

        // Imprimir los elementos de la colección
        System.out.println("Elementos en el TreeSet:" + nombres );

        System.out.println("Elementos en el TreeSet:" + numeros );
    }
}
