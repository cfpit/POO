package treeset;

public class Persona implements Comparable<Persona> {
    //atributos
    private String nombre;
    private int edad;

    //constructor vacio
    public Persona() {
    }

    //constructor con parametros
    public Persona(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    //getters y setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    //toString
    @Override
    public String toString() {
        return "Persona{" +
                "nombre='" + nombre + '\'' +
                ", edad=" + edad +
                '}';
    }

    //ordenamiento de personas por nombre
    // @Override
    // public int compareTo(Persona o) {
    //     return this.nombre.compareTo(o.nombre);
    // }

    //ordenamiento de personas por edad
    @Override    
    public int compareTo(Persona o) {
        return Integer.compare(this.edad, o.edad);
    }
}
