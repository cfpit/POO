package treeset;

import java.util.TreeSet;

public class App {
    public static void main(String[] args) {
        //creamos un TreeSet de personas
        TreeSet<Persona> personas = new TreeSet<>();

        //agregamos personas al TreeSet
        personas.add(new Persona("Juan", 30));
        personas.add(new Persona("Ana", 25));
        personas.add(new Persona("Pedro", 35));
        personas.add(new Persona("Maria", 28));

        //imprimimos el TreeSet de personas
        System.out.println("Personas ordenadas por nombre: " + personas);
        
    }
}
