create database colegio;

use colegio;

create table alumnos (
    nombre varchar(30) not null,
    edad int not null
);

insert into alumnos (nombre, edad) values ('Juan', 20);
insert into alumnos (nombre, edad) values ('Maria', 22);
insert into alumnos (nombre, edad) values ('Pedro', 19);
insert into alumnos (nombre, edad) values ('Ana', 21);

select * from alumnos;


    