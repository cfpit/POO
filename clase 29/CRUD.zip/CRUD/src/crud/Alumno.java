package crud;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Alumno {
    private String nombre;
    private int edad;
    
    public Alumno(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "Alumno{" +
                "nombre='" + nombre + '\'' +
                ", edad=" + edad +
                '}';
    }

    //metodo consultasTodos
    public static void consultarTodos() throws SQLException {
        //obtener conexion a la base de datos
        Connection unaConexion = Conexion.obtenerConexion();
        
        //armo la consulta SQL para obtener todos los alumnos
        String unaConsulta = "SELECT * FROM alumnos";
        
        //armo una sentencia preparada para ejecutar la consulta
        Statement unaSentencia = unaConexion.createStatement();

        //ejecutar la consulta SQL
        ResultSet resultados = unaSentencia.executeQuery(unaConsulta);

        //imprimir resultados
        while (resultados.next()) {
            String nombre = resultados.getString("nombre");
            int edad = resultados.getInt("edad");
            System.out.println("Nombre: " + nombre + ", Edad: " + edad);
        }

        //cerrar la conexion a la base de datos
        unaConexion.close();
    }
    
    //metodo insertar
    public static void insertar(String nombre, int edad) {
        try {
            Connection unaConexion = Conexion.obtenerConexion();
            Statement unaSentencia = unaConexion.createStatement();
            unaSentencia.executeUpdate("INSERT INTO alumnos (nombre, edad) VALUES ('" + nombre + "', " + edad + ")");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	//metodo actualizar
    public static void actualizar(String nombre, int edad) {
        try {
            Connection conn = Conexion.obtenerConexion();
            Statement stmt = conn.createStatement();
            stmt.executeUpdate("UPDATE alumnos SET nombre='" + nombre + "', edad=" + edad + " WHERE nombre='" + nombre + "'");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //metodo eliminar
    public static void eliminar(String nombre) {
        try {
            Connection conn = Conexion.obtenerConexion();
            Statement stmt = conn.createStatement();
            stmt.executeUpdate("DELETE FROM alumnos WHERE nombre='" + nombre + "'");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
