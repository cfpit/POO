package crud;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    public static Connection obtenerConexion() {
        //conexion por jdbc     
        //variables y cadena de conexion
        String url = "jdbc:mysql://localhost:3306/colegio";
        String usuario = "root";
        String contraseña = "1234";

        try {
            Connection conexion = DriverManager.getConnection(url, usuario, contraseña);
            return conexion;
        } catch (SQLException e) {
            e.printStackTrace();
        }


        return null;
        
    }
}
