package crud;

public class App {
    public static void main(String[] args) throws Exception {
        // Prueba de Conexion a BD
        Conexion.obtenerConexion();

        // Prueba de consulta a BD
        Alumno.consultarTodos();

        System.out.println("------------------------------");

        // insercion de un nuevo alumno
        Alumno.insertar("Luis", 25);
        Alumno.consultarTodos();

        System.out.println("------------------------------");

        // modificacion de un alumno
        Alumno.actualizar("Luis", 26);
        Alumno.consultarTodos();

        System.out.println("------------------------------");

        //eliminacion de un alumno
        Alumno.eliminar("Luis");
        Alumno.consultarTodos();
    }
}
