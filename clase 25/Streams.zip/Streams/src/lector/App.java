package lector;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class App {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        // creo un objeto File que guardara la ruta(path) del archivo a leer
        File archivo = new File("src/lector/origen.txt");

        // creo un Stream que se encargara de leer el archivo
        BufferedReader lector = new BufferedReader(new FileReader(archivo));

        // variables auxiliares
        String lineaLeida = "";
        boolean eof = false;

        // algortimo de lectura del archivo
        while (!eof) {
            try {
                // leo una linea del archivo
                lineaLeida = lector.readLine();

                // si la linea leida es null, entonces se ha llegado al final del archivo
                if (lineaLeida == null) {
                    eof = true;
                } else {
                    // si no es null, entonces imprimo la linea leida
                    System.out.println(lineaLeida);
                }
            } catch (FileNotFoundException e) {
                System.out.println("No se encontro el archivo!!!");
            } catch (IOException e) {
                System.out.println("Error de lectura");
            } catch (Exception e) {
                System.out.println("Se produjo un Error");
            }
        }
    }
}
