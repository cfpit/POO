package copiador;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class App {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        //creo los 2 objetos File
        File archivoOrigen = new File("src/copiador/origen.txt");
        File archivoDestino = new File("src/copiador/destino.txt");

        //creo los 2 streams(buffers) para leer y escribir (es decir, copiar)
        BufferedReader lector = new BufferedReader(new FileReader(archivoOrigen));
        BufferedWriter escritor = new BufferedWriter(new FileWriter(archivoDestino));

        //variables auxiliares
        String lineaLeida = "";

        //algoritmo de copia
        while ((lineaLeida = lector.readLine()) != null) {
            escritor.write(lineaLeida);
            escritor.newLine();
        }

        //cierro los streams
        lector.close();
        escritor.close();
    }
}
