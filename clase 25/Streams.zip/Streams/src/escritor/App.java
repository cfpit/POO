package escritor;

import java.io.File;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class App {
    public static void main(String[] args) throws IOException {
        //creo un objeto File para escribir en un archivo de texto
        File archivo = new File("src/escritor/destino.txt");

        //creo un stream de escritura para escribir en el archivo
        BufferedWriter escritor = new BufferedWriter(new FileWriter(archivo));

        //escribo una línea de texto en el archivo
        escritor.write("Esta es la linea #1.");
        escritor.newLine(); //agrego un salto de línea
        escritor.write("Esta es la linea #2.");
        escritor.newLine(); 
        escritor.write("Esta es la linea #3.");
        escritor.newLine(); 
        //metodo append para agregar texto al final del archivo sin sobrescribirlo
        escritor.append("Esta es la linea #4.");
        escritor.newLine();
        //cierro el stream de escritura para guardar los cambios en el archivo
        escritor.close();
    }

}
